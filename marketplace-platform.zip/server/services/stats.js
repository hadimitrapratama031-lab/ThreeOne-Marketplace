import { Product } from '../models/index.js';
import { emitPublic, emitAdmin, setChangeHook } from '../lib/realtime.js';
import { summarize, visibleProducts } from './reviews.js';
import { getSetting } from './settings.js';

/**
 * Statistik beranda yang dihitung langsung dari database (bukan angka yang diketik manual):
 *  - orders : "Pesanan Selesai" = jumlah terjual (total `sold` seluruh produk). Bertambah otomatis setiap pembayaran berhasil.
 *  - rating : rata-rata bintang dari ulasan yang tayang (0 bila belum ada), + ratingCount.
 */
export async function liveStats() {
  const [sold, visible] = await Promise.all([
    Product.aggregate([{ $group: { _id: null, n: { $sum: '$sold' } } }]),
    visibleProducts(),
  ]);
  const ids = [...visible.keys()];
  const summary = await summarize({ status: 'published', productId: { $in: [...ids, null] } });   // sama dengan halaman Rating
  return { orders: sold[0]?.n ?? 0, rating: summary.avg ?? 0, ratingCount: summary.total };
}

/** Gabungkan angka hidup ke pengaturan stats (sisanya, mis. `support`, tetap dari pengaturan admin). */
export async function withLiveStats(stats = {}) {
  const { customers, ...rest } = stats;   // `customers` bawaan data lama tidak dipakai lagi
  return { ...rest, ...(await liveStats()) };
}

/** "N pesanan selesai" di halaman produk = angka yang sama dengan beranda. */
export async function withLiveProductPage(pp = {}) {
  return { ...pp, completedOrders: (await liveStats()).orders };
}

/** Umumkan statistik terbaru ke Marketplace + Admin. */
export async function broadcastStats() {
  try {
    const [stats, page] = await Promise.all([getSetting('stats'), getSetting('productPage')]);
    const [s, p] = await Promise.all([withLiveStats(stats), withLiveProductPage(page)]);
    emitPublic('settings:update', { key: 'stats', value: s });
    emitAdmin('settings:update', { key: 'stats', value: s });
    emitPublic('settings:update', { key: 'productPage', value: p });
    emitAdmin('settings:update', { key: 'productPage', value: p });
  } catch (err) {
    console.error('[stats] gagal menyiarkan statistik:', err.message);
  }
}

// Produk (terjual berubah) atau ulasan berubah -> siarkan ulang statistik (digabung agar tidak beruntun)
let timer;
setChangeHook((entity) => {
  if (entity !== 'product' && entity !== 'review') return;
  clearTimeout(timer);
  timer = setTimeout(broadcastStats, 300);
  timer.unref?.();
});
